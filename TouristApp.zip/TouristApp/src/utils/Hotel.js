class Hotel {
    constructor(city, name, street, number, prize, distance, lng, lat) {
        this.city = city;
        this.name = name;
        this.street = street;
        this.number = number;
        this.prize = prize;
        this.distance = distance;
        this.lng = lng;
        this.lat = lat;
    }
}
